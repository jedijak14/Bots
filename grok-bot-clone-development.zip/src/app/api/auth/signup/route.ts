import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, userSettings } from "@/db/schema";
import { createSession, handleError, hashPassword, throttle } from "@/lib/auth";

export const dynamic = "force-dynamic";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { email?: string; password?: string; name?: string };
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!EMAIL.test(email) || email.length > 200) {
      return Response.json({ error: "Enter a valid email address." }, { status: 400 });
    }
    if (password.length < 8) {
      return Response.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    }
    if (password.length > 200) return Response.json({ error: "Password is too long." }, { status: 400 });
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!throttle(`signup:${ip}`, 20)) {
      return Response.json({ error: "Too many attempts. Try again in a few minutes." }, { status: 429 });
    }

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing[0]) {
      return Response.json({ error: "An account with this email already exists. Try signing in." }, { status: 409 });
    }
    const local = email.split("@")[0].replace(/[._-]+/g, " ").trim();
    const displayName =
      String(body.name ?? "").trim().slice(0, 40) || local.charAt(0).toUpperCase() + local.slice(1) || "You";
    const [user] = await db
      .insert(users)
      .values({ email, passwordHash: await hashPassword(password), displayName })
      .returning({ id: users.id });
    await db.insert(userSettings).values({ userId: user.id }).onConflictDoNothing();
    await createSession(user.id);
    return Response.json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
