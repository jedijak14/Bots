import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { clearThrottle, createSession, handleError, hashPassword, throttle, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

let dummyHash: string | null = null;

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { email?: string; password?: string };
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    const key = `login:${ip}:${email}`;
    if (!throttle(key)) {
      return Response.json({ error: "Too many attempts. Try again in a few minutes." }, { status: 429 });
    }
    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    if (!user) {
      // keep timing similar whether or not the account exists
      dummyHash ??= await hashPassword("dummy-password");
      await verifyPassword(password, dummyHash);
      return Response.json({ error: "Incorrect email or password." }, { status: 401 });
    }
    if (!(await verifyPassword(password, user.passwordHash))) {
      return Response.json({ error: "Incorrect email or password." }, { status: 401 });
    }
    clearThrottle(key);
    await createSession(user.id);
    return Response.json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
