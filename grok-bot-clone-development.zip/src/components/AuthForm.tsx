"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { SHAPE_IDS, COLOR_ROWS } from "@/lib/shapes";
import { BotAvatar } from "./BotAvatar";
import { Spinner } from "./icons";
import { cx, inputCls } from "./ui";

const COLORS_CYCLE = COLOR_ROWS.flat();

export function AuthForm() {
  const router = useRouter();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [i, setI] = useState(5);

  // the hero bot keeps changing its look
  useEffect(() => {
    const t = setInterval(() => setI((n) => n + 1), 2600);
    return () => clearInterval(t);
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(mode === "signin" ? "/api/auth/login" : "/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || "Something went wrong.");
      router.replace("/");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setBusy(false);
    }
  }

  return (
    <>
      <div className="wallpaper" aria-hidden="true" />
      <div className="fixed inset-0 grid place-items-center overflow-y-auto p-4">
        <div className="fade-up w-full max-w-[400px] rounded-[22px] border border-white/10 bg-[#0c0c0c]/95 p-7 shadow-[0_40px_120px_rgba(0,0,0,0.65)] backdrop-blur">
          <div className="flex h-[120px] items-center justify-center">
            <BotAvatar shape={SHAPE_IDS[i % SHAPE_IDS.length]} color={COLORS_CYCLE[(i * 3) % COLORS_CYCLE.length]} size={104} />
          </div>
          <h1 className="mt-3 text-center text-[24px] font-semibold tracking-tight">{mode === "signin" ? "Welcome back" : "Create your account"}</h1>
          <p className="mt-1.5 text-center text-[13.5px] text-neutral-400">
            {mode === "signin" ? "Sign in with your email to see your bots." : "Just an email and a password. Your bots stay private to you."}
          </p>

          <div className="mt-6 grid grid-cols-2 rounded-full bg-[#161616] p-1 text-[13px]" role="tablist">
            {(["signin", "signup"] as const).map((m) => (
              <button
                key={m}
                role="tab"
                aria-selected={mode === m}
                onClick={() => {
                  setMode(m);
                  setError(null);
                }}
                className={cx("rounded-full py-2 font-medium transition", mode === m ? "bg-white text-black" : "text-neutral-400 hover:text-white")}
              >
                {m === "signin" ? "Sign in" : "Create account"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-5 space-y-3">
            <input
              type="email"
              required
              autoFocus
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              aria-label="Email"
              className={inputCls}
            />
            <input
              type="password"
              required
              minLength={mode === "signup" ? 8 : undefined}
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={mode === "signup" ? "Password (8+ characters)" : "Password"}
              aria-label="Password"
              className={inputCls}
            />
            {error && (
              <p role="alert" className="rounded-xl bg-[#2a1215] px-3.5 py-2.5 text-[13px] text-[#ff8b98]">
                {error}
              </p>
            )}
            <button
              type="submit"
              disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-white py-3 text-[14px] font-semibold text-black transition hover:bg-neutral-200 active:scale-[0.98] disabled:opacity-60"
            >
              {busy && <Spinner size={15} />}
              {mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
